let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(x) {
    showSlides(slideIndex += x);
}
function currentSlide(x) {
    showSlides(slideIndex = x);
}

function showSlides(x) {

    let slides = document.querySelectorAll('.economy-offers__slider-item');
    let dots = document.querySelectorAll('.economy-offers__slider-dot');
    if (x > slides.length) {
        slideIndex = 1;
    };
    if (x < 1) {
        slideIndex = slides.length;
    };
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = 'none';
    };
    for (let i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(' active', '');
    };
    slides[slideIndex - 1].style.display = 'block';
    dots[slideIndex - 1].className += ' active';
}

document.querySelector('.copyright').innerText = 'Copyright ' + new Date().getFullYear();


